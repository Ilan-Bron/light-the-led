package com.example.light_the_led;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Settings_activity extends AppCompatActivity
{

    EditText get_ip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_layout);


        get_ip = (EditText)findViewById(R.id.Settings_edit_text_ip_adress);

    }


    public void save_and_return_to_prev_activity(View view)
    {
        String new_ip = get_ip.getText().toString();

        Connection.IP_ADDRESS = new_ip;


        Intent return_to_prev_activity = new Intent();
        setResult(2 , return_to_prev_activity);
        finish();

    }
}


