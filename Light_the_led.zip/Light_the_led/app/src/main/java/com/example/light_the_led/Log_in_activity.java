package com.example.light_the_led;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.concurrent.ExecutionException;

public class Log_in_activity extends AppCompatActivity {

    EditText user_name_edit_text;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in_activity_layout);

        user_name_edit_text = (EditText)findViewById(R.id.Log_in_edit_text_user_name);

    }



    public void Log_in_button_method(View view) throws ExecutionException, InterruptedException
    {
        String user_name = user_name_edit_text.getText().toString();

        Connection connect_to_server_first_time = new Connection();
        connect_to_server_first_time.execute(user_name);

        String action_string = connect_to_server_first_time.get();

        Intent start_main_activity = new Intent(this , MainActivity.class);

        start_main_activity.putExtra("action_string" , action_string);
        start_main_activity.putExtra("user_name" , user_name);

        startActivity(start_main_activity);
    }



    public void open_settings_fab_method(View view)
    {
        Intent open_settings_intent = new Intent(this , Settings_activity.class);

        startActivityForResult(open_settings_intent , 2);
    }


}
