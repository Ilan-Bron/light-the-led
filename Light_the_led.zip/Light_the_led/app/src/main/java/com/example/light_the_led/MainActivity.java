package com.example.light_the_led;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static String user_name = "ilan";
    public static String user_action_string = "";

    public final String LOG_TAG = "main activity";

    Button turn_on, turn_off, flicker, change_line, run_line;

    ArrayList<Led_action> action_list;          //the array which will hold all the actions in order
    Action_list_adapter adapter;

    ListView action_list_view;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        turn_on = (Button) findViewById(R.id.Btn_turn_on);
        turn_off = (Button) findViewById(R.id.Btn_turn_off);             //initialization
        flicker = (Button) findViewById(R.id.Btn_flicker);
        change_line = (Button) findViewById(R.id.Btn_change_line);
        run_line = (Button) findViewById(R.id.Btn_run_line);

        action_list_view = (ListView) findViewById(R.id.action_list_view);

        action_list = new ArrayList<>();          //the array which will hold all the actions in order
        adapter = new Action_list_adapter(MainActivity.this, R.layout.led_action_layout, action_list);


        Intent calling_intent =  getIntent();

        user_name = calling_intent.getStringExtra("user_name");
        user_action_string = calling_intent.getStringExtra("action_string");

        generate_list_from_action_string(user_action_string);

        action_list_view.setAdapter(adapter);


        action_list_view.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long l) {
                AlertDialog.Builder alert_dialog = new AlertDialog.Builder(MainActivity.this);

                alert_dialog.setTitle("Delete this action");
                alert_dialog.setMessage("Do you wish to delete this action");
                alert_dialog.setCancelable(true);

                alert_dialog.setNegativeButton("No", null);
                alert_dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        action_list.remove(position);
                        adapter.notifyDataSetChanged();
                    }
                });


                alert_dialog.show();

                return true;
            }
        });
    }


    public void simple_turn_on_off_buttons_method(final View view) {
        final Dialog d = new Dialog(this);

        d.setContentView(R.layout.simple_action_dialog);
        d.setTitle("Choose time");                          //create the dialog
        d.setCancelable(true);

        final int action_type;
        switch (view.getId()) {
            case R.id.Btn_turn_on:
                action_type = 0;
                break;

            case R.id.Btn_turn_off:
                action_type = 1;
                break;

            default:
                action_type = -1;

        }


        Button btn_save = (Button) d.findViewById(R.id.simple_action_dialog_btn_save);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText get_time = (EditText) d.findViewById(R.id.simple_action_dialog_edit_text_time);
                int time = Integer.parseInt(get_time.getText().toString());

                Led_action curr_action = new Led_action(action_type, time);

                action_list.add(curr_action);
                adapter.notifyDataSetChanged();

                d.dismiss();
            }
        });


        Button btn_run_now = (Button) d.findViewById(R.id.simple_action_dialog_run_now_button);
        btn_run_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String action_type_str;

                if (action_type == 0)
                    action_type_str = "ton";

                else
                    action_type_str = "tof";

                EditText get_time = (EditText) d.findViewById(R.id.simple_action_dialog_edit_text_time);
                int time = Integer.parseInt(get_time.getText().toString());

                new Connection().execute(user_name, "1" + action_type_str + "." + time + ".0");

                d.dismiss();
            }
        });

        d.show();

    }


    public void flicker_button_method(View view) {
        final Dialog d = new Dialog(this);

        d.setContentView(R.layout.flicker_action_dialog);
        d.setTitle("flicker action");                          //create the dialog
        d.setCancelable(true);


        Button btn_save = (Button) d.findViewById(R.id.flicker_action_dialog_save_btn);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText get_time = (EditText) d.findViewById(R.id.flicker_action_dialog_action_time);
                int time = Integer.parseInt(get_time.getText().toString());

                EditText get_extra_params = (EditText) d.findViewById(R.id.flicker_action_dialog_add_params);
                int extra_params = Integer.parseInt(get_extra_params.getText().toString());


                Led_action curr_action = new Led_action(2, time, extra_params);

                action_list.add(curr_action);
                adapter.notifyDataSetChanged();

                d.dismiss();
            }
        });

        Button btn_run_now = (Button) d.findViewById(R.id.flicker_action_dialog_run_now_button);
        btn_run_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText get_time = (EditText) d.findViewById(R.id.flicker_action_dialog_action_time);
                int time = Integer.parseInt(get_time.getText().toString());

                EditText get_extra_params = (EditText) d.findViewById(R.id.flicker_action_dialog_add_params);
                int extra_params = Integer.parseInt(get_extra_params.getText().toString());

                new Connection().execute(user_name, "1f" + "." + time + ".0." + extra_params);

                d.dismiss();
            }
        });

        d.show();
    }


    public void change_in_server_button_method(View view) {
        String curr_action_string = construct_action_String();

        Toast.makeText(this, curr_action_string, Toast.LENGTH_LONG).show();
        this.user_action_string = curr_action_string;

        new Connection().execute(user_name, this.user_action_string);
    }


    public void run_current_line_button_method(View view) {
        new Connection().execute(user_name, this.user_action_string, "r");
    }


    public String construct_action_String()
    //this method will construct the action string from the list
    {
        String action_string = "n";

        for (int ind = 0; ind < action_list.size(); ++ind) {
            Led_action curr_action = action_list.get(ind);
            String curr_action_str = "";

            curr_action_str += curr_action.getAction_type_str();
            curr_action_str += ".";
            curr_action_str += curr_action.getAction_time();
            curr_action_str += ".";
            curr_action_str += curr_action.getLed_num();
            curr_action_str += ".";

            if (curr_action.getAdditional_params() != -1)
                curr_action_str += curr_action.getAdditional_params();

            action_string += curr_action_str;

            if (ind != action_list.size() - 1)
                action_string += "_";

        }


        return action_string;
    }


    public void clear_list_fab_method(View view)
    {
        action_list.clear();
        adapter.notifyDataSetChanged();

    }


    public void open_settings_fab_method(View view)
    {
        Intent open_settings_intent = new Intent(this , Settings_activity.class);

        startActivityForResult(open_settings_intent , 2);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        // check if the request code is same as what is passed  here it is 2
        if(requestCode==2)
        {
            Log.d(LOG_TAG , "returned from settings successfully");
        }

    }


    private void generate_list_from_action_string(String user_action_string)
    {
        String[] action_array = user_action_string.split("_");

        for(int ind = 0; ind < action_array.length ; ind ++)
        {
            String curr_action = action_array[ind];

            String[] arg_array = curr_action.split("\\.");

            String action_type = arg_array[0];
            int action_time = Integer.parseInt(arg_array[1]);
            int action_operand = Integer.parseInt(arg_array[2]);
            int additional_params = -1;

            if(arg_array.length > 3)
                additional_params = Integer.parseInt(arg_array[3]);

            int action_type_num = -1;
            if(action_type.equals("ton"))
                action_type_num = 0;
            else if(action_type.equals("tof"))
                action_type_num = 1;
            else if(action_type.equals("f"))
                action_type_num = 2;



            Led_action led_action = new Led_action(action_type_num , action_time , additional_params);
            action_list.add(led_action);

        }

    adapter.notifyDataSetChanged();
    }



}
